# Gmail XSS PoC

This is a proof-of-concept (PoC) for a cross-site scripting (XSS) vulnerability in Gmail.

## Steps to Reproduce

1. Open `index.html` in a browser (preferably Edge or IE11).
2. Click the **"Open Gmail"** button.
3. In the new Gmail window, open DevTools and run:
   ```js
   addEventListener("message", function(e) { console.log(e.data); });
   ```
4. Look for a message prefix like `abc123|...` and copy the channel name.
5. Paste it back into the PoC and click **"Send XSS Message"**.
6. If successful, an XSS payload will be executed in Gmail's context.

## Note

Modern browsers like Chrome/Firefox may block this via CSP. This PoC is for security research and reporting only.
